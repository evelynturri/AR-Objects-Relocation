package com.qualcomm.snapdragon.spaces.unitycontroller;
import android.util.Log;
import com.qualcomm.snapdragon.spaces.spacescontroller.ui.spaces_controller.SpacesControllerFragment;

public class SpacesController {
    public static void ResetPose() {
        SpacesControllerFragment.Companion.ResetPose();
    }
}
